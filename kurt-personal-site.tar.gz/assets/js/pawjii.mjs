import { normalizePawjiiState } from './page-state.mjs';

const classroom = document.querySelector('[data-classroom]');
const dialog = classroom?.querySelector('[data-course-dialog]');
const dialogContent = dialog?.querySelector('[data-dialog-content]');
const dialogStatus = dialog?.querySelector('[data-dialog-status]');
const closeButton = dialog?.querySelector('[data-course-close]');
const status = classroom?.querySelector('.course-status');
const filterButtons = [...(classroom?.querySelectorAll('[data-course-filter]') || [])];
const courseElements = [...(classroom?.querySelectorAll('.pawjii-course[data-course-id]') || [])];
const courseLinks = [...(classroom?.querySelectorAll('[data-course-link]') || [])];
const anchors = [...document.querySelectorAll('[id]')].map(element => element.id);
const courses = courseElements.map(element => ({
  id: element.dataset.courseId,
  species: element.dataset.species,
  element,
  lessons: [...element.querySelectorAll('.lesson-body[data-lesson-id]')].map(lesson => ({ id: lesson.dataset.lessonId, element: lesson })),
}));

let restoreFocus = null;
let bodyOverflow = document.body?.style.overflow || '';
let scheduled = false;
let lastAppliedURL = '';
let installController = null;
const initialStatus = status?.textContent || '';
const initialDialogLabel = dialog?.getAttribute('aria-label') || '';

function currentState() {
  return normalizePawjiiState({ hash: location.hash, search: location.search, anchors, courses });
}

function replaceURL(state) {
  const url = new URL(location.href);
  url.hash = state.hash;
  url.search = state.search;
  history.replaceState(null, '', url);
}

function pushURL({ hash, search }, { restoreOnClose = false } = {}) {
  const url = new URL(location.href);
  url.hash = hash;
  url.search = search;
  lastAppliedURL = '';
  history.pushState(null, '', url);
  applyURLState(null, restoreOnClose);
}

function message(key, count) {
  const source = classroom.dataset[key] || '';
  if (count === undefined) return source;
  let formatted = String(count);
  try { formatted = new Intl.NumberFormat(document.documentElement.lang).format(count); } catch { /* A decimal string remains readable. */ }
  return source.replace('{count}', formatted);
}

function applyFilter(filter, selectedCourseId = null) {
  const visible = courses.filter(course => filter === 'all' || course.species === filter);
  for (const course of courses) course.element.hidden = !visible.includes(course) && course.id !== selectedCourseId;
  for (const button of filterButtons) button.setAttribute('aria-pressed', String(button.dataset.courseFilter === filter));
  status.textContent = message('filterResult', visible.length);
}

function removeCloneIds(root) {
  for (const element of root.querySelectorAll('[id]')) element.removeAttribute('id');
  for (const element of root.querySelectorAll('[aria-labelledby]')) element.removeAttribute('aria-labelledby');
}

function showLesson(root, lessonId, focus = false) {
  const articles = [...root.querySelectorAll('.lesson-body[data-lesson-id]')];
  for (const article of articles) {
    const active = article.dataset.lessonId === lessonId;
    article.hidden = !active;
    const heading = article.querySelector('h3');
    if (heading) {
      heading.removeAttribute('id');
      if (active) {
        heading.id = 'dialog-lesson-title';
        article.setAttribute('aria-labelledby', heading.id);
      }
    }
  }
  for (const link of root.querySelectorAll('[data-lesson-link]')) {
    if (link.dataset.lessonLink === lessonId) link.setAttribute('aria-current', 'step');
    else link.removeAttribute('aria-current');
  }
  if (focus) root.querySelector('#dialog-lesson-title')?.focus();
}

function wireReading(root, courseId) {
  root.addEventListener('click', event => {
    const link = event.target.closest('a');
    if (!link || !root.contains(link)) return;
    const lessonId = link.dataset.lessonLink || (link.hash.startsWith('#lesson-') ? link.hash.slice(8) : '');
    if (lessonId) {
      event.preventDefault();
      pushURL({ hash: `#course=${encodeURIComponent(courseId)}&lesson=${encodeURIComponent(lessonId)}`, search: currentState().search });
    } else if (link.hash === '#courses') {
      event.preventDefault();
      pushURL({ hash: '#courses', search: currentState().search }, { restoreOnClose: true });
    }
  }, { signal: installController.signal });
}

function openCourse(state, trigger = null) {
  const course = courses.find(candidate => candidate.id === state.courseId);
  if (!course) return;
  const courseFallback = course.element.querySelector('summary');
  const restoreCourse = restoreFocus?.closest?.('[data-course-id]')?.dataset.courseId;
  if (trigger || restoreCourse !== course.id) restoreFocus = trigger || courseFallback;
  const title = document.createElement('h2');
  title.id = 'dialog-course-title';
  title.textContent = course.element.querySelector('.course-title')?.textContent || '';
  const reading = course.element.querySelector('.course-reading').cloneNode(true);
  removeCloneIds(reading);
  showLesson(reading, state.lessonId);
  wireReading(reading, course.id);
  dialogContent.replaceChildren(title, reading);
  dialog.setAttribute('aria-labelledby', title.id);
  dialog.removeAttribute('aria-label');
  if (!dialog.open) {
    bodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialog.showModal();
  }
  showLesson(reading, state.lessonId, true);
}

function closeCourse(restore = true) {
  if (dialog.open) dialog.close();
  document.body.style.overflow = bodyOverflow;
  if (!restore) return;
  const fallback = courses.find(course => course.id === dialog.dataset.courseId)?.element.querySelector('summary');
  let target = restoreFocus?.isConnected ? restoreFocus : fallback;
  if (target?.closest('[hidden]')) target = courseLinks.find(link => link.dataset.courseLink === dialog.dataset.courseId) || null;
  restoreFocus = null;
  target?.focus();
}

function applyURLState(trigger = null, restoreOnClose = false) {
  const state = currentState();
  if (location.hash !== state.hash || location.search !== state.search) replaceURL(state);
  if (location.href === lastAppliedURL && !state.error && !trigger && !restoreOnClose) return;
  lastAppliedURL = location.href;
  applyFilter(state.filter, state.courseId);
  const errorMessage = state.error ? message(state.error === 'unknown-course' ? 'invalidCourse' : 'invalidLesson') : '';
  if (errorMessage) status.textContent = errorMessage;
  dialogStatus.textContent = state.error === 'unknown-lesson' ? errorMessage : '';
  dialogStatus.hidden = !dialogStatus.textContent;
  if (!state.courseId) {
    closeCourse(restoreOnClose);
    return;
  }
  dialog.dataset.courseId = state.courseId;
  openCourse(state, trigger);
}

function scheduleURLState() {
  if (scheduled) return;
  scheduled = true;
  queueMicrotask(() => {
    scheduled = false;
    applyURLState();
  });
}

function validateClassroom() {
  if (!classroom || !dialog || !dialogContent || !dialogStatus || !closeButton || !status) throw new Error('Incomplete classroom controls');
  if (typeof dialog.showModal !== 'function' || typeof dialog.close !== 'function') throw new Error('Dialog is not supported');
  if (filterButtons.length !== 3 || new Set(filterButtons.map(button => button.dataset.courseFilter)).size !== 3) throw new Error('Incomplete course filters');
  if (!courses.length || courseLinks.length !== courses.length) throw new Error('Incomplete course index');
  for (const course of courses) {
    const summary = course.element.querySelector(':scope > summary');
    const reading = course.element.querySelector(':scope > .course-reading');
    const title = course.element.querySelector('.course-title');
    if (!summary || !reading || !title || !course.lessons.length) throw new Error(`Incomplete course ${course.id}`);
    if (!course.lessons.every(lesson => lesson.id && lesson.element.querySelector('h3'))) throw new Error(`Incomplete lessons for ${course.id}`);
  }
}

function rollbackEnhancement() {
  installController?.abort();
  installController = null;
  classroom?.classList.remove('classroom-enhanced');
  if (dialog?.open) dialog.close();
  if (document.body) document.body.style.overflow = bodyOverflow;
  for (const course of courses) course.element.hidden = false;
  for (const button of filterButtons) button.setAttribute('aria-pressed', String(button.dataset.courseFilter === 'all'));
  if (status) status.textContent = initialStatus;
  if (dialogStatus) { dialogStatus.textContent = ''; dialogStatus.hidden = true; }
  dialogContent?.replaceChildren();
  dialog?.removeAttribute('aria-labelledby');
  if (initialDialogLabel) dialog?.setAttribute('aria-label', initialDialogLabel);
  restoreFocus = null;
  scheduled = false;
  lastAppliedURL = '';
}

function install() {
  validateClassroom();
  installController = new AbortController();
  const listen = (target, type, listener) => target.addEventListener(type, listener, { signal: installController.signal });
  for (const link of courseLinks) listen(link, 'click', event => {
    const course = courses.find(candidate => candidate.id === link.dataset.courseLink);
    if (!course?.lessons[0]) return;
    event.preventDefault();
    pushURL({ hash: `#course=${encodeURIComponent(course.id)}&lesson=${encodeURIComponent(course.lessons[0].id)}`, search: currentState().search });
    restoreFocus = link;
  });
  for (const course of courses) {
    const summary = course.element.querySelector('summary');
    listen(summary, 'click', event => {
      event.preventDefault();
      pushURL({ hash: `#course=${encodeURIComponent(course.id)}&lesson=${encodeURIComponent(course.lessons[0].id)}`, search: currentState().search });
      restoreFocus = summary;
    });
  }
  for (const button of filterButtons) listen(button, 'click', () => {
    const state = currentState();
    const filter = button.dataset.courseFilter;
    pushURL({ hash: state.hash, search: filter === 'all' ? '' : `?pet=${filter}` });
  });
  listen(closeButton, 'click', () => pushURL({ hash: '#courses', search: currentState().search }, { restoreOnClose: true }));
  listen(dialog, 'cancel', event => {
    if (event.defaultPrevented) return;
    event.preventDefault();
    pushURL({ hash: '#courses', search: currentState().search }, { restoreOnClose: true });
  });
  listen(window, 'hashchange', scheduleURLState);
  listen(window, 'popstate', scheduleURLState);
  applyURLState();
  classroom.classList.add('classroom-enhanced');
}

try { install(); } catch (error) {
  rollbackEnhancement();
  console.error('Pawjii classroom enhancement unavailable.', error);
}
