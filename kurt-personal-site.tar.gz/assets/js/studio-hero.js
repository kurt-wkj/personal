(() => {
  const gallery = document.querySelector('[data-studio-gallery]');
  if (!gallery) return;
  const projects = [...gallery.querySelectorAll('[data-studio-project]')];
  if (projects.length < 2) return;

  const picks = [...gallery.querySelectorAll('[data-studio-pick]')];
  const status = gallery.querySelector('[data-studio-status]');
  let current = 0;
  function show(index) {
    current = (index + projects.length) % projects.length;
    projects.forEach((project, i) => { project.hidden = i !== current; });
    picks.forEach((button, i) => { button.setAttribute('aria-pressed', String(i === current)); });
    status.textContent = picks[current].textContent;
  }

  picks.forEach((button, index) => button.addEventListener('click', () => show(index)));
  gallery.querySelector('[data-studio-step="next"]').addEventListener('click', () => show(current + 1));
  gallery.querySelector('[data-studio-step="previous"]').addEventListener('click', () => show(current - 1));
  const rtl = getComputedStyle(gallery).direction === 'rtl';
  gallery.addEventListener('keydown', event => {
    if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    if (event.key === 'Home') show(0);
    else if (event.key === 'End') show(projects.length - 1);
    else show(current + (event.key === (rtl ? 'ArrowLeft' : 'ArrowRight') ? 1 : -1));
    if (event.target.closest('.studio-picker, .studio-project')) picks[current].focus();
  });

  // Only intentional, single-finger horizontal swipes change the project.
  // Vertical scrolling, pinch zoom, and taps retain their native actions.
  const viewport = gallery.querySelector('.studio-projects');
  let first;
  viewport.addEventListener('touchstart', event => {
    first = event.touches.length === 1 ? event.touches[0] : null;
  }, { passive: true });
  viewport.addEventListener('touchcancel', () => { first = null; });
  viewport.addEventListener('touchend', event => {
    if (!first) return;
    const last = event.changedTouches[0];
    const dx = last.clientX - first.clientX;
    const dy = last.clientY - first.clientY;
    first = null;
    if (Math.abs(dx) < 55 || Math.abs(dx) <= Math.abs(dy) * 1.6) return;
    if (event.cancelable) event.preventDefault();
    show(current + ((dx < 0) !== rtl ? 1 : -1));
  }, { passive: false });
  gallery.querySelectorAll('[data-studio-controls]').forEach(controls => { controls.hidden = false; });
})();
