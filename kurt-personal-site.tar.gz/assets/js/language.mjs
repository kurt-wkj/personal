import { preservedState } from './page-state.mjs';

const pickers = [...document.querySelectorAll('[data-language-picker]')];
const courses = [...document.querySelectorAll('[data-course-id]')].map(course => ({
  id: course.dataset.courseId,
  lessons: [...course.querySelectorAll('[data-lesson-id]')].map(lesson => ({ id: lesson.dataset.lessonId })),
}));
const anchors = [...document.querySelectorAll('[id]')].map(element => element.id);

const state = () => preservedState({
  page: document.body.dataset.page || '', hash: location.hash, search: location.search, anchors, courses,
});

function updateLinks(links) {
  const safe = state();
  for (const link of links) {
    const url = new URL(link.href);
    url.search = safe.search;
    url.hash = safe.hash;
    link.href = url.href;
  }
}

for (const picker of pickers) {
  const summary = picker.querySelector('summary');
  const search = picker.querySelector('input[type="search"]');
  const empty = picker.querySelector('[data-language-empty]');
  const searchRegion = picker.querySelector('.language-search');
  const links = [...picker.querySelectorAll('a[data-locale]')];
  if (!summary || !search || !empty || !searchRegion || !links.length) continue;
  const filter = () => {
    const query = search.value.trim().normalize('NFKC').toLocaleLowerCase();
    for (const link of links) link.hidden = !link.dataset.search.normalize('NFKC').toLocaleLowerCase().includes(query);
    empty.hidden = links.some(link => !link.hidden);
  };
  searchRegion.hidden = false;
  search.addEventListener('input', filter);
  picker.addEventListener('toggle', () => {
    if (!picker.open) return;
    for (const other of pickers) if (other !== picker) other.open = false;
    search.value = '';
    filter();
    updateLinks(links);
  });
  picker.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !picker.open) return;
    event.preventDefault();
    event.stopPropagation();
    picker.open = false;
    summary.focus();
  });
  for (const link of links) link.addEventListener('click', () => {
    updateLinks(links);
    try { localStorage.setItem('kurt-locale', link.dataset.locale); } catch { /* Preferences are optional. */ }
  });
}

document.addEventListener('click', event => {
  for (const picker of pickers) if (!picker.contains(event.target)) picker.open = false;
});

if (document.body.dataset.legacy === 'true' && pickers.length) {
  try {
    const saved = localStorage.getItem('kurt-locale');
    const links = [...pickers[0].querySelectorAll('a[data-locale]')];
    const destination = links.find(link => link.dataset.locale === saved);
    if (destination && saved !== document.body.dataset.locale) {
      updateLinks(links);
      location.replace(destination.href);
    }
  } catch { /* The full English legacy page remains usable without storage. */ }
}
