document.documentElement.classList.add("js");

document.querySelectorAll("[data-nav-toggle]").forEach((toggle) => {
  const menuId = toggle.getAttribute("aria-controls");
  const menu = document.getElementById(menuId);
  if (!menu) return;

  const closeMenu = (restoreFocus = false) => {
    toggle.setAttribute("aria-expanded", "false");
    menu.dataset.open = "false";
    if (restoreFocus) toggle.focus();
  };

  toggle.addEventListener("click", () => {
    const nextOpen = toggle.getAttribute("aria-expanded") !== "true";
    toggle.setAttribute("aria-expanded", String(nextOpen));
    menu.dataset.open = String(nextOpen);
  });

  menu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => closeMenu());
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && menu.dataset.open === "true") closeMenu(true);
  });
});
