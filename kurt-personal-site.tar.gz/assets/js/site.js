document.documentElement.classList.add("js");

if (document.body.dataset.page === "") {
  const sectionLinks = document.querySelectorAll(".site-nav [data-home-section]");
  const updateCurrentSection = () => {
    const target = document.getElementById(location.hash.slice(1));
    const section = target?.closest("#works, #stickers, #contact, #blog")?.id;
    const current = section === "stickers" ? "works" : section || "about";
    for (const link of sectionLinks) {
      if (link.dataset.homeSection === current) link.setAttribute("aria-current", "location");
      else link.removeAttribute("aria-current");
    }
  };
  updateCurrentSection();
  window.addEventListener("hashchange", updateCurrentSection);
}

document.querySelectorAll("[data-nav-toggle]").forEach((toggle) => {
  const menuId = toggle.getAttribute("aria-controls");
  const menu = document.getElementById(menuId);
  if (!menu) return;

  const closeMenu = (restoreFocus = false) => {
    toggle.setAttribute("aria-expanded", "false");
    menu.dataset.open = "false";
    if (restoreFocus) toggle.focus();
  };

  toggle.addEventListener("click", () => {
    const nextOpen = toggle.getAttribute("aria-expanded") !== "true";
    toggle.setAttribute("aria-expanded", String(nextOpen));
    menu.dataset.open = String(nextOpen);
  });

  menu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => closeMenu());
  });

  document.addEventListener("keydown", (event) => {
    if (!event.defaultPrevented && event.key === "Escape" && menu.dataset.open === "true") closeMenu(true);
  });
});

document.querySelectorAll('.product-controls, .sticker-controls').forEach(controls => {
  const previous = controls.querySelector('[data-product-step="previous"], [data-sticker-step="previous"]');
  const next = controls.querySelector('[data-product-step="next"], [data-sticker-step="next"]');
  const viewport = next && document.getElementById(next.getAttribute('aria-controls'));
  if (!viewport || !previous) return;

  const cards = [...viewport.children];
  controls.hidden = cards.length < 2;
  const rtl = () => getComputedStyle(viewport).direction === 'rtl';
  // Geometry avoids browser-specific RTL scrollLeft conventions.
  const distance = card => {
    const frame = viewport.getBoundingClientRect(); const item = card.getBoundingClientRect();
    const inset = parseFloat(getComputedStyle(viewport).scrollPaddingInlineStart) || 0;
    return (rtl() ? frame.right - item.right : item.left - frame.left) - inset;
  };
  const update = () => {
    const frame = viewport.getBoundingClientRect();
    previous.disabled = !cards.length || distance(cards[0]) >= -2;
    const last = cards.at(-1)?.getBoundingClientRect();
    next.disabled = !last || (rtl() ? last.left >= frame.left - 2 : last.right <= frame.right + 2);
  };
  const moveTo = card => {
    if (!card) return;
    const offset = distance(card);
    // A tiny nudge at an existing snap point can advance a whole card.
    if (Math.abs(offset) <= 2) return;
    viewport.scrollBy({left: offset * (rtl() ? -1 : 1), behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth'});
  };
  const step = forward => {
    const candidate = forward ? cards.find(card => distance(card) > 2) : [...cards].reverse().find(card => distance(card) < -2);
    moveTo(candidate || (forward ? cards.at(-1) : cards[0]));
  };
  previous.addEventListener('click', () => step(false));
  next.addEventListener('click', () => step(true));
  viewport.addEventListener('keydown', event => {
    if (event.target !== viewport || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    if (event.key === 'Home') moveTo(cards[0]);
    else if (event.key === 'End') moveTo(cards.at(-1));
    else step(event.key === (rtl() ? 'ArrowLeft' : 'ArrowRight'));
  });
  viewport.addEventListener('scroll', update, {passive: true});
  new ResizeObserver(update).observe(viewport);
  update();
});
