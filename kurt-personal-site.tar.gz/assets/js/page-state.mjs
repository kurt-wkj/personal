const safeParams = value => {
  const source = String(value || '').replace(/^[#?]/, '');
  if (!source) return { params: new URLSearchParams(), malformed: false };
  try {
    decodeURIComponent(source);
    return { params: new URLSearchParams(source), malformed: false };
  } catch {
    return { params: new URLSearchParams(), malformed: true };
  }
};

const repeated = (params, name) => params.getAll(name).length !== 1;

export function normalizePawjiiState({ hash = '', search = '', anchors = [], courses = [] } = {}) {
  const query = safeParams(search);
  const pet = !query.malformed && !repeated(query.params, 'pet') ? query.params.get('pet') : null;
  const filter = ['dog', 'cat'].includes(pet) ? pet : 'all';
  const normalizedSearch = filter === 'all' ? '' : `?pet=${filter}`;
  const fragment = safeParams(hash);
  const hasCourseState = String(hash).replace(/^#/, '').startsWith('course=') || fragment.params.has('course') || fragment.params.has('lesson');
  if (!hasCourseState) {
    const anchor = hash === '#courses' ? '#courses' : safeAnchor(hash, anchors);
    return { courseId: null, lessonId: null, filter, hash: anchor, search: normalizedSearch, error: null };
  }
  if (fragment.malformed || repeated(fragment.params, 'course')) {
    return { courseId: null, lessonId: null, filter, hash: '#courses', search: normalizedSearch, error: 'unknown-course' };
  }
  const courseId = fragment.params.get('course');
  const course = courses.find(candidate => candidate.id === courseId);
  if (!course) return { courseId: null, lessonId: null, filter, hash: '#courses', search: normalizedSearch, error: 'unknown-course' };
  const lessonValues = fragment.params.getAll('lesson');
  const requestedLesson = lessonValues.length === 1 ? lessonValues[0] : null;
  const lesson = course.lessons.find(candidate => candidate.id === requestedLesson);
  const lessonId = lesson?.id || course.lessons[0]?.id || null;
  const error = lessonValues.length > 1 || (requestedLesson && !lesson) ? 'unknown-lesson' : null;
  const normalizedHash = lessonId ? `#course=${encodeURIComponent(course.id)}&lesson=${encodeURIComponent(lessonId)}` : `#course=${encodeURIComponent(course.id)}`;
  return { courseId: course.id, lessonId, filter, hash: normalizedHash, search: normalizedSearch, error };
}

export function preservedState({ page = '', hash = '', search = '', anchors = [], courses = [] } = {}) {
  if (page === 'pawjii/') {
    const state = normalizePawjiiState({ hash, search, anchors, courses });
    return { hash: state.hash, search: state.search };
  }
  return { hash: safeAnchor(hash, anchors), search: '' };
}

function safeAnchor(hash, anchors) {
  if (!String(hash).startsWith('#')) return '';
  try {
    const id = decodeURIComponent(String(hash).slice(1));
    return anchors.includes(id) ? `#${encodeURIComponent(id)}` : '';
  } catch {
    return '';
  }
}
